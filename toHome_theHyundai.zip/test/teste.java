package test;

public class teste {

}
